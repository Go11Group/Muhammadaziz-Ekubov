package model

type Product struct {
	ID            int
	Name          string
	Description   string
	Price         int
	StockQuantity int
}
